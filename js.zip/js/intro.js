document.getElementById("start-button").addEventListener("click", function() {
    window.location.href = "calibration.html"; // Navigate to calibration.html
});
